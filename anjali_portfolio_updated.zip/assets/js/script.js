// Simple JS for interaction
document.addEventListener('DOMContentLoaded', () => {
    console.log('Portfolio loaded successfully!');
});

# Anjali's Portfolio Website

This is a simple frontend portfolio website built using HTML, CSS, and JavaScript.

## 🛠 Features
- About section
- Projects showcase
- Contact info

## 🚀 How to Run
1. Clone or download the repo.
2. Open `index.html` in your browser.

## 📁 Structure
- `index.html`: Main webpage
- `assets/css/style.css`: Styles
- `assets/js/script.js`: JavaScript

## 👩‍💻 Made by Anjali Gandhi
